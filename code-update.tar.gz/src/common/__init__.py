from .custom_exception import CustomException

__all__ = ["CustomException"]