blocked_token_db: dict[str, float] = {}
user_db: list[dict] = []
session_db: dict[str, dict] = {}